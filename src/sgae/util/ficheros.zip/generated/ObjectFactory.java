//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantaci�n de la referencia de enlace (JAXB) XML v2.2.8-b130911.1802 
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas las modificaciones realizadas en este archivo se perder�n si se vuelve a compilar el esquema de origen. 
// Generado el: 2018.04.26 a las 11:04:28 AM CEST 
//


package sgae.util.generated;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the sgae.util.generated package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: sgae.util.generated
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link PersonaXML }
     * 
     */
    public PersonaXML createPersonaXML() {
        return new PersonaXML();
    }

    /**
     * Create an instance of {@link MiembroInfoBreve }
     * 
     */
    public MiembroInfoBreve createMiembroInfoBreve() {
        return new MiembroInfoBreve();
    }

    /**
     * Create an instance of {@link Link }
     * 
     */
    public Link createLink() {
        return new Link();
    }

    /**
     * Create an instance of {@link PistasXML }
     * 
     */
    public PistasXML createPistasXML() {
        return new PistasXML();
    }

    /**
     * Create an instance of {@link PistaInfoBreve }
     * 
     */
    public PistaInfoBreve createPistaInfoBreve() {
        return new PistaInfoBreve();
    }

    /**
     * Create an instance of {@link AlbumInfoBreve }
     * 
     */
    public AlbumInfoBreve createAlbumInfoBreve() {
        return new AlbumInfoBreve();
    }

    /**
     * Create an instance of {@link AlbumXML }
     * 
     */
    public AlbumXML createAlbumXML() {
        return new AlbumXML();
    }

    /**
     * Create an instance of {@link Estadisticas }
     * 
     */
    public Estadisticas createEstadisticas() {
        return new Estadisticas();
    }

    /**
     * Create an instance of {@link Raiz }
     * 
     */
    public Raiz createRaiz() {
        return new Raiz();
    }

    /**
     * Create an instance of {@link PistaXML }
     * 
     */
    public PistaXML createPistaXML() {
        return new PistaXML();
    }

    /**
     * Create an instance of {@link PersonaInfoBreve }
     * 
     */
    public PersonaInfoBreve createPersonaInfoBreve() {
        return new PersonaInfoBreve();
    }

    /**
     * Create an instance of {@link GruposMusicalesXML }
     * 
     */
    public GruposMusicalesXML createGruposMusicalesXML() {
        return new GruposMusicalesXML();
    }

    /**
     * Create an instance of {@link GrupoMusicalInfoBreve }
     * 
     */
    public GrupoMusicalInfoBreve createGrupoMusicalInfoBreve() {
        return new GrupoMusicalInfoBreve();
    }

    /**
     * Create an instance of {@link AlbumesXML }
     * 
     */
    public AlbumesXML createAlbumesXML() {
        return new AlbumesXML();
    }

    /**
     * Create an instance of {@link PersonasXML }
     * 
     */
    public PersonasXML createPersonasXML() {
        return new PersonasXML();
    }

    /**
     * Create an instance of {@link MiembrosXML }
     * 
     */
    public MiembrosXML createMiembrosXML() {
        return new MiembrosXML();
    }

    /**
     * Create an instance of {@link GrupoMusicalXML }
     * 
     */
    public GrupoMusicalXML createGrupoMusicalXML() {
        return new GrupoMusicalXML();
    }

}
